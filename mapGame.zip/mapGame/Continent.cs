﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mapGame
{
    public class Continent
    {
        public int owner = 0;
        public int resources = 0;
        public bool invaded = false;
        public int turnsInvaded = 0;
    }
}
